package io.hexlet.blog.model;

public interface BaseEntity {
    // public Long getId();
}
